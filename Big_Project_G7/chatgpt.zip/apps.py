from django.apps import AppConfig


class ChatgptConfig(AppConfig):
    name = 'chatgpt'
